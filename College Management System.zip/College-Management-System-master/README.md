# College Management System
This is a College Management System project. It uses SQL queries instead of ORMs.
This project uses the SQlite as its database.

# Getting started
1. Start by cloning this repository to your system: git clone <repo-url>
2. Go to the directory where you have cloned the repository: cd College Management System
3. Install required npm dependencies: npm install
4. Start the server: node index.js This project runs on port 3000 by default, but you may change this by setting the "PORT" environment variable.
5. Go to http://localhost:3000/. Replace 3000 with whatever port value you have set. Ignore if you are using the default value.
